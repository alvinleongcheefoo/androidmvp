androidmvp
==========

MVP Android Example used to explain how to use this pattern in our Android apps. This code was created to support an article explanation:

[Android MVP @ antonioleiva.com (English)](http://antonioleiva.com/mvp-android)

[Android MVP @ LiME Creative Labs (Spanish)](http://www.limecreativelabs.com/mvp-android/)

[![Android Arsenal](https://img.shields.io/badge/Android%20Arsenal-androidmvp-brightgreen.svg?style=flat)](https://android-arsenal.com/details/3/1514)
